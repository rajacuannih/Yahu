setTimeout(function () {
    document.location = '/views.html?view=popup';
}, 1);